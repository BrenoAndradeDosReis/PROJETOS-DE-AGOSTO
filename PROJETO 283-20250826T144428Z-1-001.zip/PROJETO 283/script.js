document.addEventListener('DOMContentLoaded', () => {
    // --- Elementos do DOM ---
    const petMoodEl = document.getElementById('pet-mood');
    const petImageEl = document.getElementById('pet-image');
    const petNameEl = document.getElementById('pet-name');

    const statusHungerEl = document.getElementById('status-hunger');
    const statusHappinessEl = document.getElementById('status-happiness');
    const statusEnergyEl = document.getElementById('status-energy');
    const statusCleanlinessEl = document.getElementById('status-cleanliness');
    const statusAgeEl = document.getElementById('status-age');
    const statusHealthEl = document.getElementById('status-health');

    const actionFeedBtn = document.getElementById('action-feed');
    const actionPlayBtn = document.getElementById('action-play');
    const actionSleepBtn = document.getElementById('action-sleep');
    const actionCleanBtn = document.getElementById('action-clean');
    const actionMedicateBtn = document.getElementById('action-medicate');

    const saveGameBtn = document.getElementById('save-game-btn');
    const loadGameBtn = document.getElementById('load-game-btn');
    const resetGameBtn = document.getElementById('reset-game-btn');

    const messageBox = document.getElementById('message-box');
    const messageText = document.getElementById('message-text');
    const closeMessageBtn = document.getElementById('close-message-btn');
    const actionEvolveBtn = document.getElementById('action-evolve');

    // --- Constantes do Jogo ---
    const GAME_INTERVAL_MS = 1000;
    const AGE_INTERVAL_SECONDS = 10;
    const MAX_STAT = 100;
    const MIN_STAT = 0;
    const LOW_STAT_THRESHOLD = 30;

    // --- Definições do Pet (Evolução e Aparência) ---
    const PET_STAGES = [
        { name: 'Ovo', emoji: '🥚', minAge: 0, maxAge: 1 },
        { name: 'Bebê', emoji: '🐕', minAge: 1, maxAge: 5 },
        { name: 'Criança', emoji: '🐩', minAge: 5, maxAge: 15 },
        { name: 'Adolescente', emoji: '🐕‍🦺', minAge: 15, maxAge: 30 },
        { name: 'Adulto', emoji: '🦮', minAge: 30, maxAge: Infinity }
    ];

    let tamagotchi = {
        name: 'Ovo',
        hunger: MAX_STAT,
        happiness: MAX_STAT,
        energy: MAX_STAT,
        cleanliness: MAX_STAT,
        health: MAX_STAT,
        ageDays: 0,
        lastUpdateTime: Date.now(),
        isSleeping: false,
        isSick: false,
        isAlive: true
    };

    let gameIntervalId = null;

    /**
     * Exibe uma mensagem modal.
     * @param {string} message - A mensagem a ser exibida.
     */
    function showMessage(message) {
        messageText.textContent = message;
        messageBox.style.display = 'flex';
    }

    /**
     * Oculta a mensagem modal.
     */
    function hideMessage() {
        messageBox.style.display = 'none';
    }

    /**
     * Atualiza a exibição de todas as estatísticas e imagens do pet.
     */
    function updateDisplay() {
        const petStage = PET_STAGES.find(stage => tamagotchi.ageDays >= stage.minAge && tamagotchi.ageDays < stage.maxAge);
        petNameEl.textContent = petStage ? petStage.name : 'Ovo';

        petImageEl.textContent = getPetEmoji();
        petMoodEl.textContent = getPetMoodEmoji();

        statusHungerEl.textContent = `${Math.floor(tamagotchi.hunger)}%`;
        statusHappinessEl.textContent = `${Math.floor(tamagotchi.happiness)}%`;
        statusEnergyEl.textContent = `${Math.floor(tamagotchi.energy)}%`;
        statusCleanlinessEl.textContent = `${Math.floor(tamagotchi.cleanliness)}%`;
        statusAgeEl.textContent = `${Math.floor(tamagotchi.ageDays)} dias`;
        statusHealthEl.textContent = `${Math.floor(tamagotchi.health)}%`;

        statusHungerEl.classList.toggle('low', tamagotchi.hunger < LOW_STAT_THRESHOLD);
        statusHappinessEl.classList.toggle('low', tamagotchi.happiness < LOW_STAT_THRESHOLD);
        statusEnergyEl.classList.toggle('low', tamagotchi.energy < LOW_STAT_THRESHOLD);
        statusCleanlinessEl.classList.toggle('low', tamagotchi.cleanliness < LOW_STAT_THRESHOLD);
        statusHealthEl.classList.toggle('low', tamagotchi.health < LOW_STAT_THRESHOLD);
        
        // Desativa botões de ação se o pet não estiver vivo ou estiver dormindo
        actionSleepBtn.disabled = tamagotchi.isSleeping;
        actionFeedBtn.disabled = !tamagotchi.isAlive || tamagotchi.isSleeping;
        actionPlayBtn.disabled = !tamagotchi.isAlive || tamagotchi.isSleeping;
        actionCleanBtn.disabled = !tamagotchi.isAlive || tamagotchi.isSleeping;
        actionMedicateBtn.disabled = !tamagotchi.isAlive || tamagotchi.isSleeping;
        actionEvolveBtn.disabled = tamagotchi.ageDays < 1;
    }

    /**
     * Retorna o emoji do pet baseado no seu estado (vivo, dormindo, doente, etc.).
     * @returns {string} O emoji do pet.
     */
    function getPetEmoji() {
        if (!tamagotchi.isAlive) return '👻';
        if (tamagotchi.isSleeping) return '😴';
        if (tamagotchi.isSick) return '🤢';

        for (const stage of PET_STAGES) {
            if (tamagotchi.ageDays >= stage.minAge && tamagotchi.ageDays < stage.maxAge) {
                return stage.emoji;
            }
        }
        return '🥚';
    }

    /**
     * Retorna o emoji de humor do pet baseado na média de suas estatísticas.
     * @returns {string} O emoji de humor.
     */
    function getPetMoodEmoji() {
        if (!tamagotchi.isAlive) return '💀';
        if (tamagotchi.isSleeping) return '💤';
        if (tamagotchi.isSick) return '🤢';

        const avgHappiness = (tamagotchi.hunger + tamagotchi.happiness + tamagotchi.energy + tamagotchi.cleanliness) / 4;

        if (avgHappiness > 80) return '🤩';
        if (avgHappiness > 60) return '😊';
        if (avgHappiness > 40) return '😐';
        if (avgHappiness > 20) return '😟';
        return '😭';
    }

    /**
     * Garante que uma estatística esteja dentro dos limites de 0 a 100.
     * @param {number} stat - O valor da estatística.
     * @returns {number} O valor da estatística ajustado.
     */
    function clampStat(stat) {
        return Math.max(MIN_STAT, Math.min(MAX_STAT, stat));
    }

    /**
     * Realiza uma ação no Tamagotchi, como alimentar ou brincar.
     * @param {string} actionType - O tipo de ação a ser realizada ('feed', 'play', 'sleep', 'clean', 'medicate').
     */
    function performAction(actionType) {
        if (!tamagotchi.isAlive) {
            showMessage('Seu Tamagotchi não está mais vivo.');
            return;
        }
        if (tamagotchi.isSleeping && actionType !== 'sleep') {
            showMessage('Seu Tamagotchi está dormindo.');
            return;
        }

        switch (actionType) {
            case 'feed':
                if (tamagotchi.hunger === MAX_STAT) {
                    showMessage('Seu Tamagotchi não está com fome.');
                    return;
                }
                tamagotchi.hunger = clampStat(tamagotchi.hunger + 20);
                tamagotchi.happiness = clampStat(tamagotchi.happiness + 5);
                showMessage('Você alimentou seu Tamagotchi!');
                break;
            case 'play':
                if (tamagotchi.happiness === MAX_STAT) {
                    showMessage('Seu Tamagotchi já está muito feliz.');
                    return;
                }
                tamagotchi.happiness = clampStat(tamagotchi.happiness + 25);
                tamagotchi.energy = clampStat(tamagotchi.energy - 10);
                showMessage('Você brincou com seu Tamagotchi!');
                break;
            case 'sleep':
                if (tamagotchi.energy === MAX_STAT) {
                    showMessage('Seu Tamagotchi não está com sono.');
                    return;
                }
                tamagotchi.isSleeping = true;
                petImageEl.style.transform = 'scale(0.8)';
                showMessage('Seu Tamagotchi foi dormir.');
                break;
            case 'clean':
                if (tamagotchi.cleanliness === MAX_STAT) {
                    showMessage('Seu Tamagotchi já está limpo.');
                    return;
                }
                tamagotchi.cleanliness = MAX_STAT;
                tamagotchi.happiness = clampStat(tamagotchi.happiness + 10);
                showMessage('Você limpou seu Tamagotchi!');
                break;
            case 'medicate':
                if (!tamagotchi.isSick) {
                    showMessage('Seu Tamagotchi não está doente.');
                    return;
                }
                tamagotchi.health = clampStat(tamagotchi.health + 30);
                tamagotchi.isSick = false;
                showMessage('Você medicou seu Tamagotchi! 💉');
                break;
            case 'evolve':
                const currentStageIndex = PET_STAGES.findIndex(stage => tamagotchi.ageDays >= stage.minAge && tamagotchi.ageDays < stage.maxAge);
                const nextStage = PET_STAGES[currentStageIndex + 1];
                if (nextStage) {
                    tamagotchi.ageDays = nextStage.minAge;
                    showMessage(`Seu Tamagotchi evoluiu para a fase ${nextStage.name}!`);
                } else {
                    showMessage('Seu Tamagotchi já alcançou a fase final.');
                }
                break;
        }
        updateDisplay();
        saveGame();
    }

    /**
     * O loop principal do jogo que atualiza as estatísticas do Tamagotchi.
     */
    function gameLoop() {
        if (!tamagotchi.isAlive) {
            clearInterval(gameIntervalId);
            gameIntervalId = null;
            return;
        }

        const now = Date.now();
        const elapsedTimeInSeconds = (now - tamagotchi.lastUpdateTime) / 1000;
        tamagotchi.lastUpdateTime = now;

        if (!tamagotchi.isSleeping) {
            tamagotchi.hunger = clampStat(tamagotchi.hunger - (2 * elapsedTimeInSeconds));
            tamagotchi.happiness = clampStat(tamagotchi.happiness - (1 * elapsedTimeInSeconds));
            tamagotchi.energy = clampStat(tamagotchi.energy - (1 * elapsedTimeInSeconds));
            tamagotchi.cleanliness = clampStat(tamagotchi.cleanliness - (0.5 * elapsedTimeInSeconds));
        } else {
            tamagotchi.energy = clampStat(tamagotchi.energy + (5 * elapsedTimeInSeconds));
            tamagotchi.happiness = clampStat(tamagotchi.happiness + (2 * elapsedTimeInSeconds));
            tamagotchi.health = clampStat(tamagotchi.health + (1 * elapsedTimeInSeconds));
            if (tamagotchi.energy >= MAX_STAT) {
                tamagotchi.isSleeping = false;
                petImageEl.style.transform = 'scale(1)';
                showMessage('Seu Tamagotchi acordou!');
            }
        }

        tamagotchi.ageDays += elapsedTimeInSeconds / AGE_INTERVAL_SECONDS;
        const currentStage = PET_STAGES.find(stage => tamagotchi.ageDays >= stage.minAge && tamagotchi.ageDays < stage.maxAge);
        if (currentStage && tamagotchi.name !== currentStage.name) {
            tamagotchi.name = currentStage.name;
            showMessage(`Seu Tamagotchi evoluiu para a fase ${currentStage.name}!`);
        }

        let healthPenalty = 0;
        if (tamagotchi.hunger < LOW_STAT_THRESHOLD) healthPenalty += 5;
        if (tamagotchi.happiness < LOW_STAT_THRESHOLD) healthPenalty += 3;
        if (tamagotchi.energy < LOW_STAT_THRESHOLD) healthPenalty += 2;
        if (tamagotchi.cleanliness < LOW_STAT_THRESHOLD) healthPenalty += 4;
        if (tamagotchi.isSick) healthPenalty += 10;
        
        tamagotchi.health = clampStat(tamagotchi.health - (healthPenalty * elapsedTimeInSeconds));

        if (tamagotchi.isSick && tamagotchi.health >= LOW_STAT_THRESHOLD + 20) {
            tamagotchi.isSick = false;
            showMessage('Seu Tamagotchi se recuperou da doença!');
        } else if (!tamagotchi.isSick && tamagotchi.health < LOW_STAT_THRESHOLD && Math.random() < 0.005 * elapsedTimeInSeconds) {
            tamagotchi.isSick = true;
            showMessage('Seu Tamagotchi ficou doente! Cuide bem dele.');
        }

        if (tamagotchi.health <= MIN_STAT) {
            tamagotchi.isAlive = false;
            showMessage('Seu Tamagotchi faleceu... 😢');
            clearInterval(gameIntervalId);
            gameIntervalId = null;
            updateDisplay();
            saveGame();
            return;
        }

        updateDisplay();
        saveGame();
    }
    
    /**
     * Salva o estado atual do jogo no Local Storage.
     */
    function saveGame() {
        localStorage.setItem('tamagotchiSave', JSON.stringify(tamagotchi));
    }

    /**
     * Carrega um jogo salvo do Local Storage.
     */
    function loadGame() {
        const savedState = localStorage.getItem('tamagotchiSave');
        if (savedState) {
            const loadedTamagotchi = JSON.parse(savedState);
            Object.assign(tamagotchi, loadedTamagotchi);

            const now = Date.now();
            const elapsedTimeInSeconds = (now - tamagotchi.lastUpdateTime) / 1000;
            
            if (tamagotchi.isAlive) {
                if (!tamagotchi.isSleeping) {
                    tamagotchi.hunger = clampStat(tamagotchi.hunger - (2 * elapsedTimeInSeconds));
                    tamagotchi.happiness = clampStat(tamagotchi.happiness - (1 * elapsedTimeInSeconds));
                    tamagotchi.energy = clampStat(tamagotchi.energy - (1 * elapsedTimeInSeconds));
                    tamagotchi.cleanliness = clampStat(tamagotchi.cleanliness - (0.5 * elapsedTimeInSeconds));
                } else {
                    tamagotchi.energy = clampStat(tamagotchi.energy + (5 * elapsedTimeInSeconds));
                    tamagotchi.happiness = clampStat(tamagotchi.happiness + (2 * elapsedTimeInSeconds));
                    tamagotchi.health = clampStat(tamagotchi.health + (1 * elapsedTimeInSeconds));
                }
                tamagotchi.ageDays += elapsedTimeInSeconds / AGE_INTERVAL_SECONDS;

                let healthPenalty = 0;
                if (tamagotchi.hunger < LOW_STAT_THRESHOLD) healthPenalty += 5;
                if (tamagotchi.happiness < LOW_STAT_THRESHOLD) healthPenalty += 3;
                if (tamagotchi.energy < LOW_STAT_THRESHOLD) healthPenalty += 2;
                if (tamagotchi.cleanliness < LOW_STAT_THRESHOLD) healthPenalty += 4;
                if (tamagotchi.isSick) healthPenalty += 10;
                
                tamagotchi.health = clampStat(tamagotchi.health - (healthPenalty * elapsedTimeInSeconds));

                if (tamagotchi.health <= MIN_STAT) {
                    tamagotchi.isAlive = false;
                    showMessage('Seu Tamagotchi faleceu enquanto você estava fora... 😢');
                } else {
                    showMessage('Jogo carregado com sucesso!');
                }
            }
            
            tamagotchi.lastUpdateTime = now;
            updateDisplay();
            startGameLoop();
        } else {
            showMessage('Nenhum jogo salvo encontrado. Iniciando um novo jogo.');
            resetGame(false);
        }
    }

    /**
     * Reinicia o jogo para o estado inicial.
     * @param {boolean} [showConfirm=true] - Se deve exibir a caixa de diálogo de confirmação.
     */
    function resetGame(showConfirm = true) {
        if (showConfirm && !confirm('Tem certeza que deseja reiniciar o jogo? Todo o progresso será perdido!')) {
            return;
        }

        clearInterval(gameIntervalId);
        gameIntervalId = null;
        tamagotchi = {
            name: 'Ovo',
            hunger: MAX_STAT,
            happiness: MAX_STAT,
            energy: MAX_STAT,
            cleanliness: MAX_STAT,
            health: MAX_STAT,
            ageDays: 0,
            lastUpdateTime: Date.now(),
            isSleeping: false,
            isSick: false,
            isAlive: true
        };
        localStorage.removeItem('tamagotchiSave');
        petImageEl.style.transform = 'scale(1)';
        showMessage('Jogo reiniciado!');
        updateDisplay();
        startGameLoop();
    }

    /**
     * Inicia o loop principal do jogo.
     */
    function startGameLoop() {
        if (gameIntervalId) {
            clearInterval(gameIntervalId);
        }
        gameIntervalId = setInterval(gameLoop, GAME_INTERVAL_MS);
    }

    // --- Event Listeners ---
    actionFeedBtn.addEventListener('click', () => performAction('feed'));
    actionPlayBtn.addEventListener('click', () => performAction('play'));
    actionSleepBtn.addEventListener('click', () => performAction('sleep'));
    actionCleanBtn.addEventListener('click', () => performAction('clean'));
    actionMedicateBtn.addEventListener('click', () => performAction('medicate'));
    actionEvolveBtn.addEventListener('click', () => performAction('evolve'));

    saveGameBtn.addEventListener('click', saveGame);
    loadGameBtn.addEventListener('click', loadGame);
    resetGameBtn.addEventListener('click', resetGame);

    closeMessageBtn.addEventListener('click', hideMessage);
    messageBox.addEventListener('click', (e) => {
        if (e.target === messageBox) {
            hideMessage();
        }
    });

    // --- Inicialização ---
    loadGame(); // Tenta carregar ao iniciar
});