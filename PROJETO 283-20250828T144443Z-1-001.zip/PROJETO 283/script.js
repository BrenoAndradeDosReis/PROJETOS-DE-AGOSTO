document.addEventListener('DOMContentLoaded', () => {
    // Referências aos elementos do DOM
    const moodImageEl = document.getElementById('mood-image');
    // Corrigido: Referência direta à tag <img>
    const petImageEl = document.getElementById('pet-img'); 
    const petNameEl = document.getElementById('pet-name');

    const statusHungerEl = document.getElementById('status-hunger');
    const statusHappinessEl = document.getElementById('status-happiness');
    const statusEnergyEl = document.getElementById('status-energy');
    const statusCleanlinessEl = document.getElementById('status-cleanliness');
    const statusAgeEl = document.getElementById('status-age');
    const statusHealthEl = document.getElementById('status-health');

    const actionFeedBtn = document.getElementById('action-feed');
    const actionPlayBtn = document.getElementById('action-play');
    const actionSleepBtn = document.getElementById('action-sleep');
    const actionCleanBtn = document.getElementById('action-clean');

    const saveGameBtn = document.getElementById('save-game-btn');
    const loadGameBtn = document.getElementById('load-game-btn');
    const resetGameBtn = document.getElementById('reset-game-btn');

    const messageBox = document.getElementById('message-box');
    const messageText = document.getElementById('message-text');
    const closeMessageBtn = document.getElementById('close-message-btn');

    // --- Configurações do Jogo ---
    const GAME_INTERVAL_MS = 1000;
    const AGE_INTERVAL_SECONDS = 10;
    const MAX_STAT = 100;
    const MIN_STAT = 0;
    const LOW_STAT_THRESHOLD = 30;

    // --- Definições do Pet (Evolução e Aparência) ---
    const PET_STAGES = [
        { name: 'Bebê', image: './1.jpg ', minAge: 1, maxAge: 5 },
        { name: 'Criança', image: './eu criança.jpg', minAge: 5, maxAge: 15 },
        { name: 'Adolescente', image: './minha dona adolescente', minAge: 15, maxAge: 30 },
        { name: 'Adulto', image: './cão da police.png', minAge: 30, maxAge: Infinity }
    ];

    // --- Definições dos Humores ---
    const MOOD_IMAGES = {
        dead: './morto.jpg',
        sleeping: './1.jpg',
        sick: './estou doente.png',
        veryHappy: './estou feliz.png',
        happy: './estou otimista hoje.png',
        neutral: './neutral cachorro.png',
        sad: './estou triste.png',
        verySad: './Estou abandonado.jpg',
    };

    // --- Estado Inicial do Tamagotchi ---
    const initialTamagotchiState = {
        hunger: MAX_STAT,
        happiness: MAX_STAT,
        energy: MAX_STAT,
        cleanliness: MAX_STAT,
        health: MAX_STAT,
        ageDays: 0,
        lastUpdateTime: Date.now(),
        isSleeping: false,
        isSick: false,
        isAlive: true
    };

    let tamagotchi = { ...initialTamagotchiState };
    let gameIntervalId = null;
    let ageCounter = 0;

    // --- Funções Auxiliares ---

    /** Exibe uma mensagem na tela usando o modal customizado. */
    function showMessage(message) {
        messageText.textContent = message;
        messageBox.style.display = 'flex';
    }

    /** Oculta a caixa de mensagem. */
    function hideMessage() {
        messageBox.style.display = 'none';
    }

    /** Atualiza a exibição de todas as estatísticas e imagens. */
    function updateDisplay() {
        const currentStage = PET_STAGES.find(stage => tamagotchi.ageDays >= stage.minAge && tamagotchi.ageDays < stage.maxAge) || PET_STAGES[0];
        tamagotchi.name = currentStage.name;

        petNameEl.textContent = tamagotchi.name;
        petImageEl.src = getPetImage(); 
        moodImageEl.src = getPetMoodImage();

        statusHungerEl.textContent = `${Math.floor(tamagotchi.hunger)}%`;
        statusHappinessEl.textContent = `${Math.floor(tamagotchi.happiness)}%`;
        statusEnergyEl.textContent = `${Math.floor(tamagotchi.energy)}%`;
        statusCleanlinessEl.textContent = `${Math.floor(tamagotchi.cleanliness)}%`;
        statusAgeEl.textContent = `${tamagotchi.ageDays} dias`;
        statusHealthEl.textContent = `${Math.floor(tamagotchi.health)}%`;

        statusHungerEl.classList.toggle('low', tamagotchi.hunger < LOW_STAT_THRESHOLD);
        statusHappinessEl.classList.toggle('low', tamagotchi.happiness < LOW_STAT_THRESHOLD);
        statusEnergyEl.classList.toggle('low', tamagotchi.energy < LOW_STAT_THRESHOLD);
        statusCleanlinessEl.classList.toggle('low', tamagotchi.cleanliness < LOW_STAT_THRESHOLD);
        statusHealthEl.classList.toggle('low', tamagotchi.health < LOW_STAT_THRESHOLD);

        actionSleepBtn.disabled = !tamagotchi.isAlive;
        actionFeedBtn.disabled = !tamagotchi.isAlive || tamagotchi.isSleeping;
        actionPlayBtn.disabled = !tamagotchi.isAlive || tamagotchi.isSleeping;
        actionCleanBtn.disabled = !tamagotchi.isAlive || tamagotchi.isSleeping;
    }

    /** Retorna a URL da imagem do pet com base em seu estado e idade. */
    function getPetImage() {
        if (!tamagotchi.isAlive) return MOOD_IMAGES.dead;
        if (tamagotchi.isSleeping) return 'url ';

        for (const stage of PET_STAGES) {
            if (tamagotchi.ageDays >= stage.minAge && tamagotchi.ageDays < stage.maxAge) {
                return stage.image;
            }
        }
        return PET_STAGES[0].image;
    }

    /** Retorna a URL da imagem de humor do pet. */
    function getPetMoodImage() {
        if (!tamagotchi.isAlive) return MOOD_IMAGES.dead;
        if (tamagotchi.isSleeping) return MOOD_IMAGES.sleeping;
        if (tamagotchi.isSick) return MOOD_IMAGES.sick;

        const avgHappiness = (tamagotchi.happiness + tamagotchi.energy + tamagotchi.cleanliness) / 3;

        if (avgHappiness > 80) return MOOD_IMAGES.veryHappy;
        if (avgHappiness > 60) return MOOD_IMAGES.happy;
        if (avgHappiness > 40) return MOOD_IMAGES.neutral;
        if (avgHappiness > 20) return MOOD_IMAGES.sad;
        return MOOD_IMAGES.verySad;
    }

    /** Garante que uma estatística esteja sempre entre MIN_STAT e MAX_STAT. */
    function clampStat(stat) {
        return Math.max(MIN_STAT, Math.min(MAX_STAT, stat));
    }

    /** Executa uma ação do usuário (alimentar, brincar, etc.). */
    function performAction(actionType) {
        if (!tamagotchi.isAlive) {
            showMessage('Seu Tamagotchi não está mais vivo.');
            return;
        }
        if (tamagotchi.isSleeping && actionType !== 'sleep') {
            showMessage('Seu Tamagotchi está dormindo.');
            return;
        }

        switch (actionType) {
            case 'feed':
                if (tamagotchi.hunger >= MAX_STAT) {
                    showMessage('Seu Tamagotchi não está com fome.');
                    return;
                }
                tamagotchi.hunger = clampStat(tamagotchi.hunger + 20);
                tamagotchi.happiness = clampStat(tamagotchi.happiness + 5);
                showMessage('Você alimentou seu Tamagotchi! 🍔');
                break;
            case 'play':
                if (tamagotchi.happiness >= MAX_STAT) {
                    showMessage('Seu Tamagotchi já está muito feliz.');
                    return;
                }
                tamagotchi.happiness = clampStat(tamagotchi.happiness + 25);
                tamagotchi.energy = clampStat(tamagotchi.energy - 10);
                showMessage('Você brincou com seu Tamagotchi! 🎾');
                break;
            case 'sleep':
                if (tamagotchi.isSleeping) {
                    showMessage('Ele já está dormindo...');
                    return;
                }
                if (tamagotchi.energy >= MAX_STAT) {
                    showMessage('Seu Tamagotchi não está com sono.');
                    return;
                }
                tamagotchi.isSleeping = true;
                petImageEl.style.transform = 'scale(0.8)';
                showMessage('Seu Tamagotchi foi dormir. 😴');
                break;
            case 'clean':
                if (tamagotchi.cleanliness >= MAX_STAT) {
                    showMessage('Seu Tamagotchi já está limpo.');
                    return;
                }
                tamagotchi.cleanliness = MAX_STAT;
                tamagotchi.happiness = clampStat(tamagotchi.happiness + 10);
                showMessage('Você limpou seu Tamagotchi! 🧼');
                break;
        }
        updateDisplay();
        // saveGame();
    }

    /** A principal função de loop do jogo, executada a cada segundo. */
    function gameLoop() {
        if (!tamagotchi.isAlive) {
            clearInterval(gameIntervalId);
            gameIntervalId = null;
            return;
        }

        // --- Envelhecimento ---
        ageCounter++;
        if (ageCounter >= AGE_INTERVAL_SECONDS) {
            tamagotchi.ageDays++;
            ageCounter = 0;
            const currentStage = PET_STAGES.find(stage => tamagotchi.ageDays >= stage.minAge && tamagotchi.ageDays < stage.maxAge);
            if (currentStage && tamagotchi.name !== currentStage.name) {
                tamagotchi.name = currentStage.name;
                showMessage(`Seu Tamagotchi evoluiu para a fase ${currentStage.name}! 🚀`);
            }
        }

        // --- Drenagem de Estatísticas (se não estiver dormindo) ---
        if (!tamagotchi.isSleeping) {
            tamagotchi.hunger = clampStat(tamagotchi.hunger - 2);
            tamagotchi.happiness = clampStat(tamagotchi.happiness - 1);
            tamagotchi.energy = clampStat(tamagotchi.energy - 1);
            tamagotchi.cleanliness = clampStat(tamagotchi.cleanliness - 0.5);
        } else { // --- Recuperação de Estatísticas (se estiver dormindo) ---
            tamagotchi.energy = clampStat(tamagotchi.energy + 5);
            tamagotchi.happiness = clampStat(tamagotchi.happiness + 2);
            tamagotchi.health = clampStat(tamagotchi.health + 1);

            if (tamagotchi.energy >= MAX_STAT) {
                tamagotchi.isSleeping = false;
                petImageEl.style.transform = 'scale(1)';
                showMessage('Seu Tamagotchi acordou! 👋');
            }
        }

        // --- Penalidade de Saúde ---
        let healthPenalty = 0;
        if (tamagotchi.hunger < LOW_STAT_THRESHOLD) healthPenalty += 5;
        if (tamagotchi.happiness < LOW_STAT_THRESHOLD) healthPenalty += 3;
        if (tamagotchi.energy < LOW_STAT_THRESHOLD) healthPenalty += 2;
        if (tamagotchi.cleanliness < LOW_STAT_THRESHOLD) healthPenalty += 4;
        tamagotchi.health = clampStat(tamagotchi.health - healthPenalty);

        // --- Lógica de Doença ---
        if (!tamagotchi.isSick && tamagotchi.health < LOW_STAT_THRESHOLD && Math.random() < 0.05) {
            tamagotchi.isSick = true;
            showMessage('Seu Tamagotchi ficou doente! Cuide bem dele. 🤒');
        } else if (tamagotchi.isSick && tamagotchi.health >= LOW_STAT_THRESHOLD + 20) {
            tamagotchi.isSick = false;
            showMessage('Seu Tamagotchi se recuperou da doença! ✨');
        }

        // --- Morte do Pet ---
        if (tamagotchi.health <= MIN_STAT) {
            tamagotchi.isAlive = false;
            showMessage('Seu Tamagotchi faleceu... 👻');
            clearInterval(gameIntervalId);
            gameIntervalId = null;
            updateDisplay();
            // saveGame();
            return;
        }

        updateDisplay();
        // saveGame();
    }

    // --- Funções de Salvar/Carregar/Resetar ---

    /** Salva o estado atual do jogo no localStorage. */
    function saveGame() {
        try {
            localStorage.setItem('tamagotchiSave', JSON.stringify(tamagotchi));
            showMessage('Jogo salvo! ✅');
        } catch (e) {
            console.error('Erro ao salvar o jogo:', e);
            showMessage('Erro ao salvar o jogo. ❌');
        }
    }

    /** Carrega o estado do jogo do localStorage ou inicia um novo se não houver. */
    function loadGame() {
        try {
            const savedState = localStorage.getItem('tamagotchiSave');
            if (savedState) {
                const loadedTamagotchi = JSON.parse(savedState);
                Object.assign(tamagotchi, loadedTamagotchi);
                tamagotchi.lastUpdateTime = Date.now();
                
                petImageEl.style.transform = tamagotchi.isSleeping ? 'scale(0.8)' : 'scale(1)';
                
                showMessage('Jogo carregado com sucesso! 🎉');
                updateDisplay();
                startGameLoop();
            } else {
                showMessage('Nenhum jogo salvo encontrado. Começando um novo... 🐣');
                resetGame();
            }
        } catch (e) {
            console.error('Erro ao carregar o jogo:', e);
            showMessage('Nenhum jogo salvo encontrado. Começando um novo... 🐣');
            resetGame();
        }
    }

    /** Reinicia o jogo para o estado inicial. */
    function resetGame() {
        clearInterval(gameIntervalId);
        gameIntervalId = null;
        tamagotchi = { ...initialTamagotchiState };
        ageCounter = 0;
        localStorage.removeItem('tamagotchiSave');
        petImageEl.style.transform = 'scale(1)';
        showMessage('Jogo reiniciado! 🔄');
        updateDisplay();
        startGameLoop();
    }

    /** Inicia o loop principal do jogo se ainda não estiver ativo. */
    function startGameLoop() {
        if (!gameIntervalId) {
            gameIntervalId = setInterval(gameLoop, GAME_INTERVAL_MS);
        }
    }

    // --- Event Listeners ---
    // Atribui os eventos de clique diretamente, sem a verificação 'if (elemento)'
    // que pode ser desnecessária se os IDs estiverem corretos no HTML.
    actionFeedBtn.addEventListener('click', () => performAction('feed')); 
    actionPlayBtn.addEventListener('click', () => performAction('play')); 
    actionSleepBtn.addEventListener('click', () => performAction('sleep')); 
    actionCleanBtn.addEventListener('click', () => performAction('clean')); 
    saveGameBtn.addEventListener('click', saveGame);
    loadGameBtn.addEventListener('click', loadGame);
    resetGameBtn.addEventListener('click', resetGame);
    closeMessageBtn.addEventListener('click', hideMessage);
    messageBox.addEventListener('click', (e) => {
        if (e.target === messageBox) {
            hideMessage();
        }
    });

    // --- Inicialização ---
    loadGame();
});