const adicionarBtn = document.getElementById('adicionarDegrau');
const removerBtn = document.getElementById('removerUltimoDegrau');
const contador = document.getElementById('contador');
const escada = document.getElementById('escada');
let degraus = [];

function getRandomColor() {
    return `hsl(${Math.random() * 360}, 70%, 60%)`;
}


function adicionarDegrau() {
    const degrau = document.createElement('div');
    degrau.classList.add('degrau');
    degrau.style.backgroundColor = getRandomColor();
    escada.appendChild(degrau);
    degraus.push(degrau);
    reorganizarDegraus();
    atualizarContador();
}


function removerDegrau() {
    const ultimo = degraus.pop();
    if (ultimo) {
        escada.removeChild(ultimo);
        reorganizarDegraus();
        atualizarContador();
    }
}


function reorganizarDegraus() {
    degraus.forEach((degrau, index) => {
        degrau.style.transform = `translate(${index * 20}px, ${-index * 20}px)`;
    });
}


function atualizarContador() {
    contador.textContent = degraus.length;
    removerBtn.disabled = degraus.length === 0;
}


adicionarBtn.addEventListener('click', adicionarDegrau);
removerBtn.addEventListener('click', removerDegrau);


atualizarContador();