const modal = document.getElementById("modal");
const modalImg = document.getElementById("modalImg");
const closeBtn = document.getElementById("closeBtn");
const toggleThemeBtn = document.getElementById("toggleTheme");

// Abrir modal ao clicar em imagem
document.querySelectorAll(".gallery img").forEach(img => {
    img.addEventListener("click", () => {
        modal.style.display = "flex";
        modalImg.src = img.src.replace("/300/200", "/900/600");
        modalImg.alt = img.alt;
    });
});

// Fechar modal pelo botão X
closeBtn.addEventListener("click", () => {
    modal.style.display = "none";
});

// Fechar modal clicando fora da imagem
modal.addEventListener("click", e => {
    if (e.target === modal) {
        modal.style.display = "none";
    }
});

// Alternar tema claro/escuro
toggleThemeBtn.addEventListener("click", () => {
    document.body.classList.toggle("dark");
    toggleThemeBtn.textContent = document.body.classList.contains("dark") ? "☀️" : "🌙";
});