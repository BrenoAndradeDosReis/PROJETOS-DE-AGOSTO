const tabs = document.querySelectorAll('.tab');
const contents = document.querySelectorAll('.tab-content');
const toggleTheme = document.getElementById('toggleTheme');


document.querySelectorAll(".tab").forEach(tab => {
    tab.addEventListener("click", () => {
        document.querySelector(".tab.active").classList.remove("active");
        tab.classList.add("active");

        document.querySelector(".tab-content.active").classList.remove("active");
        document.getElementById(`tab-${tab.dataset.tab}`).classList.add("active");
    });
})

document.getElementById("toggleTheme").addEventListener("click", () => {
    document.body.classList.toggle("dark");
    toggleTheme.textContent = document.body.classList.contains('dark') ? '☀️' : '🌙';
});