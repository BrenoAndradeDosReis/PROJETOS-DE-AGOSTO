const reguaPx = document.getElementById('regua-px');
const reguaCm = document.getElementById('regua-cm');
const reguaIn = document.getElementById('regua-in');
const indicador = document.querySelector('.indicador');
const marcador = document.getElementById('marcador');
const info = document.getElementById('info');

const DPI = 96;
const CM_TO_INCHES = 2.54;
const PX_PER_CM = DPI / CM_TO_INCHES;
const PX_PER_IN = DPI;


function getLargura() {
  return document.documentElement.scrollWidth || window.innerWidth;
}

function gerarRegua(elRegua, unidade) {
  const larguraTotal = getLargura();
  elRegua.dataset.unit = unidade.toUpperCase();

  let step, conversor;

  switch (unidade) {
    case 'px':
      step = 10;
      conversor = 1;
      break;
    case 'cm':
      step = 1;
      conversor = PX_PER_CM;
      break;
    case 'in':
      step = 0.1;
      conversor = PX_PER_IN;
      break;
    default:
      return;
  }

  elRegua.innerHTML = '';

  for (let i = 0; i * conversor < larguraTotal; i += step) {
    const pos = i * conversor;

    const marca = document.createElement('div');
    marca.classList.add('marca');
    marca.style.left = `${pos}px`;

    let altura = 10;
    let showNumber = false;

    if (unidade === 'px') {
      if (i % 50 === 0) {
        altura = 25;
        showNumber = true;
      } else if (i % 10 === 0) {
        altura = 15;
      }
    } else {
      const mod10 = Math.round(i * 10) % 10;
      const mod5 = Math.round(i * 10) % 5;

      if (mod10 === 0) {
        altura = 25;
        showNumber = true;
      } else if (mod5 === 0) {
        altura = 15;
      }
    }

    marca.style.height = `${altura}px`;

    if (showNumber) {
      const texto = document.createElement('span');
      texto.textContent = i.toFixed(1);
      texto.classList.add('numero');
      texto.style.left = `${pos + 2}px`;
      elRegua.appendChild(texto);
    }

    elRegua.appendChild(marca);
  }
}


window.addEventListener('load', () => {
  gerarRegua(reguaPx, 'px');
  gerarRegua(reguaCm, 'cm');
  gerarRegua(reguaIn, 'in');
});

// Regerar em redimensionamento de tela
window.addEventListener('resize', () => {
  gerarRegua(reguaPx, 'px');
  gerarRegua(reguaCm, 'cm');
  gerarRegua(reguaIn, 'in');
});

// Atualizar marcador com o mouse
document.addEventListener('mousemove', (e) => {
  const x = e.clientX;

  indicador.style.left = `${x}px`;
  marcador.style.left = `${x}px`;

  const valorPx = x;
  const valorCm = (x / PX_PER_CM).toFixed(2);
  const valorIn = (x / PX_PER_IN).toFixed(2);

  info.textContent = `Px: ${valorPx} | Cm: ${valorCm} | In: ${valorIn}`;
  info.style.transform = x > window.innerWidth - 120
    ? 'translateX(-110%)'
    : 'translateX(5px)';
});