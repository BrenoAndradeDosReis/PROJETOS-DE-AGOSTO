 const images = document.querySelectorAll('.gallery-grid img');
        const infoBox = document.getElementById('info-box');
        const showInfoBtn = document.getElementById('show-info-button');
        let selectedInfo = '';

        images.forEach(img => {
            img.addEventListener('click', () => {
                selectedInfo = img.getAttribute('data-info');
                infoBox.textContent = selectedInfo;
                infoBox.focus();
                showInfoBtn.disabled = false;
                showInfoBtn.setAttribute('aria-expanded', 'true');
                showInfoBtn.textContent = "Informações da imagem exibidas acima";
            });

            img.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    img.click();
                }
            });
        });

        showInfoBtn.addEventListener('click', () => {
            if (infoBox.textContent) {
                infoBox.focus();
            }
        });