document.addEventListener('DOMContentLoaded', function () {
    const produtos = [
        { nome: "Camiseta Branca", preco: 29.9, categoria: "camisetas" },
        { nome: "Camiseta Preta", preco: 34.9, categoria: "camisetas" },
        { nome: "Boné Azul", preco: 29.9, categoria: "acessorios" },
        { nome: "Pulseira", preco: 19.9, categoria: "acessorios" },
        { nome: "Camiseta Vermelha", preco: 29.9, categoria: "camisetas" },
        { nome: "Óculos de Sol", preco: 49.9, categoria: "acessorios" },
    ];

    let carrinho = [];

    const produtosEl = document.getElementById('produtos');
    const carrinhoListaEl = document.getElementById('carrinho-lista');
    const totalEl = document.getElementById('total');
    const categoriaEl = document.getElementById('categoria-filtro');
    const botaoLimparCarrinho = document.getElementById('fechar-carrinho');
    const mensagem = document.getElementById('mensagem-final');

    function exibirProdutos(filtrados = produtos) {
        produtosEl.innerHTML = '';
        filtrados.forEach(produto => {
            const produtoEl = document.createElement('div');
            produtoEl.className = 'produto';
            produtoEl.innerHTML = `
                <h3>${produto.nome}</h3>
                <p>Preço: R$ ${produto.preco.toFixed(2)}</p>
                <button>Adicionar ao Carrinho</button>
            `;
            const botao = produtoEl.querySelector('button');
            botao.addEventListener('click', () => adicionarAoCarrinho(produto));
            produtosEl.appendChild(produtoEl);
        });
    }

    function adicionarAoCarrinho(produto) {
        carrinho.push(produto);
        atualizarCarrinho();
    }

    function atualizarCarrinho() {
        carrinhoListaEl.innerHTML = '';
        let total = 0;
        carrinho.forEach(item => {
            const li = document.createElement('li');
            li.textContent = `${item.nome} - R$ ${item.preco.toFixed(2)}`;
            carrinhoListaEl.appendChild(li);
            total += item.preco;
        });
        totalEl.textContent = total.toFixed(2);
    }

    categoriaEl.addEventListener('change', function () {
        const categoria = categoriaEl.value;
        if (categoria === 'todas') {
            exibirProdutos(produtos);
        } else {
            const filtrados = produtos.filter(p => p.categoria === categoria);
            exibirProdutos(filtrados);
        }
    });

    botaoLimparCarrinho.addEventListener('click', () => {
        carrinho = [];
        atualizarCarrinho();
        mensagem.hidden = false;
    });

    // Inicializar produtos ao carregar a página
    exibirProdutos();
});