const sky = document.getElementById('sky');
const btn = document.getElementById('disparar');

btn.addEventListener('click', () => {
    const estrela = document.createElement('div');
    estrela.classList.add('estrela');

    
    const startX = Math.random() * window.innerWidth;
    estrela.style.left = `${startX}px`;
    estrela.style.top = '0px';

    // Movimento aleatório
    const dx = 200 + Math.random() * 300; 
    const dy = 400 + Math.random() * 300; 
    estrela.style.setProperty('--dx', `${dx}px`);
    estrela.style.setProperty('--dy', `${dy}px`);

    sky.appendChild(estrela);

    estrela.addEventListener('animationend', () => {
        estrela.remove();
    });
});
