document.addEventListener('DOMContentLoaded', () => {
    const mapContainer = document.getElementById('map-container');
    const mapInner = document.getElementById('map-inner');
    const mapImage = document.getElementById('interactive-map-image');
    const zoomInBtn = document.getElementById('zoom-in');
    const zoomOutBtn = document.getElementById('zoom-out');
    const resetZoomBtn = document.getElementById('reset-zoom');
    const hotspots = document.querySelectorAll('.hotspot');

    let currentZoom = 1;
    const zoomStep = 0.2;
    const minZoom = 1;
    const maxZoom = 4;
    let isDragging = false;
    let startX, startY;
    let currentPanX = 0, currentPanY = 0;

    function applyZoomAndPan() {
        mapInner.style.transform = `translate(${currentPanX}px, ${currentPanY}px) scale(${currentZoom})`;

        // Ajusta a escala dos hotspots para que eles pareçam do mesmo tamanho
        hotspots.forEach(hotspot => {
            hotspot.style.transform = `scale(${1 / currentZoom}) translate(-50%, -50%)`;
        });
    }

    function zoom(direction, clientX, clientY) {
        let newZoom = currentZoom + (direction * zoomStep);
        newZoom = Math.max(minZoom, Math.min(maxZoom, newZoom));

        if (newZoom === currentZoom) return;

        const containerRect = mapContainer.getBoundingClientRect();
        
        // Calcula a posição do mouse relativa ao container
        const mouseX = clientX - containerRect.left;
        const mouseY = clientY - containerRect.top;

        // Calcula a nova posição de pan para manter o ponto do mouse centralizado
        currentPanX = (currentPanX - mouseX) * (newZoom / currentZoom) + mouseX;
        currentPanY = (currentPanY - mouseY) * (newZoom / currentZoom) + mouseY;

        currentZoom = newZoom;
        applyZoomAndPan();
    }
    
    function resetZoom() {
        currentZoom = minZoom;
        currentPanX = 0;
        currentPanY = 0;
        applyZoomAndPan();
    }

    // --- Event Listeners ---
    
    zoomInBtn.addEventListener('click', () => zoom(1, window.innerWidth / 2, window.innerHeight / 2));
    zoomOutBtn.addEventListener('click', () => zoom(-1, window.innerWidth / 2, window.innerHeight / 2));
    resetZoomBtn.addEventListener('click', resetZoom);

    mapContainer.addEventListener('mousedown', (e) => {
        if (currentZoom > minZoom) {
            isDragging = true;
            mapContainer.style.cursor = 'grabbing';
            startX = e.clientX - currentPanX;
            startY = e.clientY - currentPanY;
        }
    });

    mapContainer.addEventListener('mouseup', () => {
        isDragging = false;
        mapContainer.style.cursor = 'grab';
    });

    mapContainer.addEventListener('mouseleave', () => {
        isDragging = false;
        mapContainer.style.cursor = 'grab';
    });

    mapContainer.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        e.preventDefault();
        currentPanX = e.clientX - startX;
        currentPanY = e.clientY - startY;
        applyZoomAndPan();
    });

    hotspots.forEach(hotspot => {
        hotspot.addEventListener('click', (e) => {
            e.stopPropagation();
            const tooltipText = hotspot.querySelector('.hotspot-tooltip').textContent;
            alert(`Você clicou no hotspot ${hotspot.id}:\n${tooltipText}`);
        });
    });

    applyZoomAndPan();
});