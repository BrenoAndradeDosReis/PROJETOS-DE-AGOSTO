const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

const particleCountSlider = document.getElementById('particleCount');
const speedSlider = document.getElementById('speed');
const particleCountValue = document.getElementById('particleCountValue');
const speedValue = document.getElementById('speedValue');

// Define o tamanho do canvas para o tamanho da janela
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// Array para armazenar todas as partículas ativas
const particles = [];

// Classe para criar uma partícula
class Particle {
    constructor(x, y, radius, speed, angle, delay) {
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.speed = speed;
        this.angle = angle;
        this.delay = delay;
        this.time = 0;
        this.hue = Math.random() * 360;
        this.opacity = 1;
    }

    // Método para atualizar a posição e o estado da partícula
    update() {
        this.time++;

        if (this.time >= this.delay) {
            this.x += Math.cos(this.angle) * this.speed;
            this.y += Math.sin(this.angle) * this.speed;
            this.opacity -= 0.005; // Ajuste para a opacidade desaparecer mais devagar
            this.radius *= 0.99; // Ajuste para o raio diminuir mais devagar
        }
    }

    // Método para desenhar a partícula no canvas
    draw() {
        if (this.time < this.delay) return;

        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(${this.hue + (this.time % 360)}, 70%, 50%, ${this.opacity})`;
        ctx.fill();
        ctx.closePath();
    }
}

// Função para criar a reação em cadeia de partículas
function createChainReaction(x, y) {
    const particleCount = parseInt(particleCountSlider.value);
    const baseSpeed = parseFloat(speedSlider.value);
    const angleStep = (Math.PI * 2) / particleCount;

    for (let i = 0; i < particleCount; i++) {
        const angle = i * angleStep;
        const speed = baseSpeed + Math.random() * 1.5;
        const radius = 5 + Math.random() * 5;
        const delay = i * 10;
        particles.push(new Particle(x, y, radius, speed, angle, delay));
    }
}

// Loop de animação principal
function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    for (let i = particles.length - 1; i >= 0; i--) {
        const particle = particles[i];
        particle.update();
        particle.draw();

        // Remove a partícula se a opacidade ou o raio for muito baixo
        if (particle.opacity <= 0 || particle.radius <= 0.1) {
            particles.splice(i, 1);
        }
    }

    requestAnimationFrame(animate);
}

// Event Listeners
canvas.addEventListener('click', (e) => {
    createChainReaction(e.clientX, e.clientY);
});

particleCountSlider.addEventListener('input', () => {
    particleCountValue.textContent = particleCountSlider.value;
});

speedSlider.addEventListener('input', () => {
    speedValue.textContent = speedSlider.value;
});

window.addEventListener('resize', () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
});

// Inicia a animação
animate();